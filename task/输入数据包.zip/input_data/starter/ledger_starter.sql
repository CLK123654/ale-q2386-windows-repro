CREATE TABLE journal_entry(
  entry_id text PRIMARY KEY,
  external_ref text UNIQUE NOT NULL,
  currency text NOT NULL
);

CREATE TABLE posting(
  entry_id text REFERENCES journal_entry(entry_id),
  line_no integer NOT NULL,
  side text NOT NULL,
  amount numeric(18,2) NOT NULL,
  PRIMARY KEY(entry_id,line_no),
  CHECK (
    (SELECT sum(CASE side WHEN 'D' THEN amount ELSE -amount END)
     FROM posting p WHERE p.entry_id=entry_id)=0
  )
);
