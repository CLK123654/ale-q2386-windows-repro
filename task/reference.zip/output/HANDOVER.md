# 结算账本交接

input_data目录提供科目、期间、入账请求、冲正请求和复核口径。

使用tools/build_delivery.py连接空数据库，脚本会部署sql目录内容并生成results目录。handover.json状态为READY时，账本可进入下一步发布检查。
